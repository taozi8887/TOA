Y88b   d88P  .d8888b.  888888b.   8888888b.     8888888 8888888 
 Y88b d88P  d88P  Y88b 888  "88b  888   Y88b      888     888   
  Y88o88P   Y88b.      888  .88P  888    888      888     888   
   Y888P     "Y888b.   8888888K.  888   d88P      888     888   
   d888b        "Y88b. 888  "Y88b 8888888P"       888     888   
  d88888b         "888 888    888 888             888     888   
 d88P Y88b  Y88b  d88P 888   d88P 888             888     888   
d88P   Y88b  "Y8888P"  8888888P"  888           8888888 8888888 

  - X I A O ' S   S O L O   B E G I N N E R   P A C K   I I -
	
============
 readme.txt
============

After the first solo beginner pack (henceforth XSBP), I felt
that wasn't enough. I need more files. More charts. Better
quality.

Thus, XSBP2 was born. With 3 more songs than the previous pack
and FOUR full charts for each song, that technically adds up to
45 charts as opposed to XSBP1's mere 27. That's 67% more! With
that said, this pack did obviously take longer to flesh out than
the first. I had trouble finding songs to step, which really
halted any progress. Once I found a list of songs to use, that's
when motivation really kicked in and this took off.

The lower level charts are a lot easier this time, while the
higher level charts are similarly significantly harder. They're
really fun nonetheless and I hope you enjoy playing them.

Cheers,
 Xiaounlimited

====================
 DIFFICULTY RATINGS
====================

XSBP1's rating system has been reimplemented, with much looser
guidelines.

> EASY (1-3) charts are mostly quarter notes with the
occassional 1/8 note. More complex charts may utilize 1/16s,
but sparingly. Rhythms are extremely oversimplified.
> NORMAL (4-6) charts start to see heavy use of 1/8 notes
and 2-3 note chords, as well as more complicated usage of 1/16
notes. Rhythms are oversimplified.
> HARD (7-9) charts use 1/16 notes in place of 1/32s and
higher, as well as chords up to around roughly 4 notes.
Rhythms are generally followed, but are occasionally
simplified where following a rhythm properly would make the
chart harder than necessary.
> PRO (10-15) charts go all out. Rhythms are properly followed
and are generally layered to a good extent.

Zenius -I- Vanisher's hard chart ended up being so difficult
(and very much like a Pro level chart) that I rated it amongst
the Pro charts.
Piano x Forte x Scandal is the pack's "boss" song and as such
boasts only a single difficult chart. It is significantly
harder than the rest of the files bar none. If you're new to
solo, don't expect to pass it right away; but make it a
goal to.

==========
 SONGLIST
==========

Tomoyasu Hotei - Battle Without Honour or Humanity
IOSYS - Border of Extacy
Hatsune Miku - Brimming White
kukui - Hikari no Rasenritsu
ZTS vo - Impronta
Dream Theater - Panic Attack
OSTER Project feat. Yamai - Piano x Forte x Scandal
Ryuusei P - RIP=RELEASE
Beltaine - Rockhill
CROW'S CLAW - Still Winter
Tatsh - Zenius -I- Vanisher (Another)
sentive - #1 Route

======
 TIPS
======

- If you find yourself repeatedly failing, turn fail off.
- If you're new to solo, don't get disparaged; keep with it.
  Perserverance will ultimately help you get better.
- Keep trying, even if you fail songs. Once you pass something
  you failed before, raise the bar again.
- I find it helps to use a non-arrow noteskin for solo to
  shirk any singles habits you might have. Start clean!
- Play files a notch higher than your skill level, but no
  higher. Trying to pass PxFxS when you're playing diff 4s
  won't make you better.

========
 THANKS
========

> GUNDAM-DUDE for helping me find songs for the pack, and file
testing.
> LONGGONE for testing the oni charts.
> MALICE for helping make Piano x Forte x Scandal suck less.
> PATASHU for letting me use his Battle Without Honour and
Humanity file in the pack.